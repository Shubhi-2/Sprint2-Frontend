import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
 import { CreatequestionComponent } from './createquestion/createquestion.component';
import { UpdatequestionComponent } from './updatequestion/updatequestion.component';
import { QuestiondetailComponent } from './questiondetail/questiondetail.component';
import { QuestionlistComponent } from './questionlist/questionlist.component';


const routes: Routes = [
  { path: '', redirectTo: 'question', pathMatch: 'full' },
  { path: 'questions', component: QuestionlistComponent },
   { path: 'add', component: CreatequestionComponent },
  { path: 'update/:sno', component: UpdatequestionComponent },
  { path: 'details/:sno', component: QuestiondetailComponent },
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
