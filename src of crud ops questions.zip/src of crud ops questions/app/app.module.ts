import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
 import { CreatequestionComponent } from './createquestion/createquestion.component';
import { UpdatequestionComponent } from './updatequestion/updatequestion.component';
import { QuestiondetailComponent } from './questiondetail/questiondetail.component';
import { QuestionlistComponent } from './questionlist/questionlist.component';

@NgModule({
  declarations: [
    AppComponent,
     CreatequestionComponent,
    UpdatequestionComponent,
    QuestiondetailComponent,
    QuestionlistComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
