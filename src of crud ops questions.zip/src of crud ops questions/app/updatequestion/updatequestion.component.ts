import { Component, OnInit } from '@angular/core';
import { Question } from '../question';
import { ActivatedRoute, Router } from '@angular/router';
import { QuestionService } from '../question.service';


@Component({
  selector: 'app-updatequestion',
  templateUrl: './updatequestion.component.html',
  styleUrls: ['./updatequestion.component.css']
})
export class UpdatequestionComponent implements OnInit {

  sno:number;
  question: Question;
  submitted=false;

  constructor(private route: ActivatedRoute,private router: Router,
    private questionService: QuestionService) { }

  ngOnInit() {
    this.question = new Question();

    this.sno = this.route.snapshot.params['sno'];
    
    this.questionService.getQuestion(this.sno)
      .subscribe(data => {
        console.log(data)
        this.question = data;
      }, error => console.log(error));
  }

  updateQuestion() {
    this.questionService.updateQuestion(this.sno, this.question)
      .subscribe(data => console.log(data), error => console.log(error));
    this.question = new Question();
    this.gotoList();
  }

  onSubmit() {
    this.updateQuestion();    
  }

  gotoList() {
    this.router.navigate(['/questions']);
  }
}
