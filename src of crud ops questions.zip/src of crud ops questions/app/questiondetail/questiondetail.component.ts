import { Question} from '../question';
import { Component, OnInit, Input } from '@angular/core';
import { QuestionService } from '../question.service';
import { QuestionlistComponent } from '../questionlist/questionlist.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-questiondetail',
  templateUrl: './questiondetail.component.html',
  styleUrls: ['./questiondetail.component.css']
})
export class QuestiondetailComponent implements OnInit {

  sno: number;
  question: Question;

  constructor(private route: ActivatedRoute,private router: Router,
    private questionService: QuestionService) { }

  ngOnInit() {
    this.question = new Question();

    this.sno = this.route.snapshot.params['sno'];
    
    this.questionService.getQuestion(this.sno)
      .subscribe(data => {
        console.log(data)
        this.question = data;
      }, error => console.log(error));
  }

  list(){
    this.router.navigate(['questions']);
  }
}

