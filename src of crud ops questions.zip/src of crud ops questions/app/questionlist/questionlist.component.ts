 import { QuestiondetailComponent } from './../questiondetail/questiondetail.component';
import { Observable } from "rxjs";
import { QuestionService } from "./../question.service";
import { Question } from "./../question";
import { Component, OnInit } from "@angular/core";
import { Router } from '@angular/router';

@Component({
  selector: 'app-questionlist',
  templateUrl: './questionlist.component.html',
  styleUrls: ['./questionlist.component.css']
})
export class QuestionlistComponent implements OnInit {

  questions: Observable<Question[]>;

  constructor(private questionService: QuestionService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.questions = this.questionService.getQuestionList();
  }


  deleteQuestion(sno: number) {
    this.questionService.deleteQuestion(sno)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  questionDetails(sno: number){
    this.router.navigate(['details', sno]);
  }

  updateQuestion(sno: number){
    this.router.navigate(['update', sno]);
  }

}
