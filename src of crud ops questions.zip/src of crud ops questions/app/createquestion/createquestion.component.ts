import { QuestionService } from '../question.service';
import { Question } from '../question';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-createquestion',
  templateUrl: './createquestion.component.html',
  styleUrls: ['./createquestion.component.css']
})
export class CreatequestionComponent implements OnInit {

    question: Question = new Question();
  submitted = false;

  constructor(private questionService: QuestionService,
    private router: Router) { }

  ngOnInit() {
  }

  newQuestion(): void {
    this.submitted = false;
    this.question = new Question();
  }

  save() {
    this.questionService.createQuestion(this.question)
      .subscribe(data => console.log(data), error => console.log(error));
    this.question = new Question();
    this.gotoList();
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/questions']);
  }
}
