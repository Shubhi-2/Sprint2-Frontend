import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class QuestionService {

 
private baseUrl = 'http://localhost:8041/subject/question';

  constructor(private http: HttpClient) { }

   getQuestion(sno: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${sno}`);
  }

  createQuestion(question: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, question);
  }

  updateQuestion(sno: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${sno}`, value);
  }

  deleteQuestion(sno: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${sno}`, { responseType: 'text' });
  }

  getQuestionList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
   }
}