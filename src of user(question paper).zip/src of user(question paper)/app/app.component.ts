import { Component } from '@angular/core';
import { QuestionService } from './service/question.service';
import { Questions } from "./questions";
import { Observable } from "rxjs";
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularProject';

  constructor(private questionService: QuestionService,private router: Router) {  
    this.list();
  
   }

  option:string;
counter:number=0;
marks:number=0;
  
  
 questionLst:Questions[];
 dataLst:any;
  errorMsg:string;
 
questionObj1 : Questions[];
questionObj : Questions;
dataObtained:boolean  = false;
arrayLength:number;

responseAnswers:string[] = new Array(10) 

i:number=0;
 
 list()
 {
 
      this.questionService.getQuestionList().subscribe (
      data => { 
         
      this.questionLst = data; 
       
      //this.callFunc();
      this.questionObj=this.questionLst[this.counter];
      this.arrayLength = this.questionLst.length;
      
       
     },
     (error) => {this.errorMsg = error; alert (this.errorMsg);  } 
     ); 

 
 }

 
 

onNext()
{
   
// alert (this.option);

  this.responseAnswers[this.counter] = this.option;

  //alert (this.option);
 if (this.counter < this.arrayLength -1)
  ++this.counter
  this.questionObj=this.questionLst[this.counter]


}


onPrev()
{
   this.responseAnswers[this.counter] = this.option;

  if (this.counter > 0)
  --this.counter
  this.questionObj=this.questionLst[this.counter]


}

endTest()
{
  return this.marks
}


onFinish()
{

   this.responseAnswers[this.counter] = this.option;
   this.marks=0;
  
   for (this.i=0; this.i < this.arrayLength; ++ this.i)
   {
     //alert ("Counter : " + this.i + " "+this.responseAnswers[this.i]);
     //alert ("Counter : " + this.i + " "+this.responseAnswers[this.i] + "  Correct value is : " +  this.questionLst[this.i].correctoption);
    if (this.responseAnswers[this.i] == this.questionLst[this.i].correctoption)
      ++this.marks;

   }
   //alert ("You have obtained "+ this.marks) 
   
   

   
   alert ("You have obtained "+ this.marks) ;
   return this.marks 
   


}

}