export class Questions{
  
    
    public questionvalue:String;
    public questiondomain:string;
    public questionmarks:number;
    public option1:string;
    public option2:string;
    public option3:string;
    public option4:string;
    public correctoption:string;
    public Sno:number;

}