import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { QuestionService } from '../service/question.service';
import { Router } from '@angular/router';
import { Questions } from "./../questions";
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-resultdetails',
  templateUrl: './resultdetails.component.html',
  styleUrls: ['./resultdetails.component.css']
})
export class ResultdetailsComponent implements OnInit {
  


  questions: Questions[];
errorMsg:string;
  constructor(private questionService: QuestionService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.questionService.getQuestionList().subscribe (
      data => { 
         
      this.questions = data;  },
     (error) => {this.errorMsg = error; alert (this.errorMsg);  } 
     ); 

  }

}
