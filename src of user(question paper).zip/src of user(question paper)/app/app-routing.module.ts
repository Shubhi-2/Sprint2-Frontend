import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { QuestiondetailsComponent } from './questiondetails/questiondetails.component';
import { ResultdetailsComponent } from './resultdetails/resultdetails.component';
// import { FirstComponent } from './first/first.component';

const routes: Routes = [

  // {path:'questions',component:QuestiondetailsComponent},
  //   {path:'questions/:Sno',component:QuestiondetailsComponent},
   {path:'results',component:ResultdetailsComponent},
    // { path: '', component: FirstComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
