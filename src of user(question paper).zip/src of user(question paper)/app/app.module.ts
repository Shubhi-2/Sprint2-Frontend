import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule }   from '@angular/forms';
import { ResultdetailsComponent } from './resultdetails/resultdetails.component';
import { DemoComponent } from './demo/demo.component';
import { QuestionlistComponent } from './questionlist/questionlist.component';


@NgModule({
  declarations: [
    AppComponent,
    
   
    ResultdetailsComponent,
    
    DemoComponent,
    
    QuestionlistComponent
    
    //FirstComponent
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
