import { Component, OnInit } from '@angular/core';
import { QuestionService } from '../service/question.service';
import { Questions } from "./../questions";
import { Observable } from "rxjs";
@Component({
  selector: 'app-questionlist',
  templateUrl: './questionlist.component.html',
  styleUrls: ['./questionlist.component.css']
})
export class QuestionlistComponent implements OnInit {

  constructor(private questionService: QuestionService) {
    this.list()
  
   }

  ngOnInit(): void {
  }
  
option:string
counter:number=0
marks:number=0
 questions:Questions[]
 questionObj:Questions=this.questions[0]

 list()
 {
  this.questionService.getQuestionList().subscribe(data=>{
      this.questions=data
      })

 }

 

next()
{
  if(this.questionObj.correctoption==this.option)
  {
    this.marks++
  }
  ++this.counter
  this.questionObj=this.questions[this.counter]


}

endTest()
{
  return this.marks
}










  
}
